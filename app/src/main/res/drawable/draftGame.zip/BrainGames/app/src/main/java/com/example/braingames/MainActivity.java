package com.example.braingames;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

//    Button leftButton = Button (findViewById(R.id.left));
//    button.setOnClickListener(new View.onClickListener);

    
    /*
    Button button = (Button) findViewById(R.id.supabutton);
    button.setOnClickListener(new View.OnClickListener() {
    public void onClick(View v) {
      Log.d("BUTTONS", "User tapped the Supabutton");
    }
});
     */
}